const keys = {};

window.addEventListener("keydown", e => {
    // Пропускаем обработку для клавиш инвентаря
    if (e.key.toLowerCase() === 'i' || e.key.toLowerCase() === 'e') {
        return;
    }

    // Блокируем управление, если открыт инвентарь
    if (window.inventory && window.inventory.isOpen) {
        return;
    }

    // Используем e.code, он всегда выдает KeyW, KeyA, ShiftLeft и т.д.
    keys[e.code] = true;
});

window.addEventListener("keyup", e => {
    keys[e.code] = false;
});