// Добавьте переменные камеры
let camera = { x: 0, y: 0 };
let zoom = 0.6;  // Отдаляем ракурс (0.6 = 60% от оригинального размера)

const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

// Установим соотношение сторон 16:9 для лучшего отображения
const GAME_ASPECT_RATIO = 16 / 9;
const BASE_WIDTH = 1920;
const BASE_HEIGHT = 1080;

function resizeCanvas() {
    const windowAspect = window.innerWidth / window.innerHeight;
    
    if (windowAspect > GAME_ASPECT_RATIO) {
        // Окно шире, ограничиваем по высоте
        canvas.height = window.innerHeight;
        canvas.width = window.innerHeight * GAME_ASPECT_RATIO;
    } else {
        // Окно выше, ограничиваем по ширине
        canvas.width = window.innerWidth;
        canvas.height = window.innerWidth / GAME_ASPECT_RATIO;
    }
    
    console.log('✓ Canvas изменен:', canvas.width, 'x', canvas.height);
}

resizeCanvas();
window.addEventListener('resize', resizeCanvas);

console.log('✓ Canvas инициализирован:', canvas.width, 'x', canvas.height);

const player = new Player();
console.log('✓ Персонаж создан');

// В game.js
let currentMap = new Map("assets/map/roomsv.png", 3000, 1080); 
console.log('✓ Карта создана');

function gameLoop() {

    player.update(currentMap);

    // Отдаляем камеру с учетом zoom
    camera.x = player.x - (canvas.width / zoom) / 2 + player.width / 2;
    camera.y = player.y - (canvas.height / zoom) / 2 + player.height / 2;

    camera.x = Math.max(0, Math.min(camera.x, currentMap.width - (canvas.width / zoom)));
    camera.y = Math.max(0, Math.min(camera.y, currentMap.height - (canvas.height / zoom)));

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Применяем масштаб
    ctx.save();
    ctx.scale(zoom, zoom);
    ctx.translate(-camera.x, -camera.y);

    currentMap.draw(ctx, camera);
    player.draw(ctx, camera);

    ctx.restore();

    requestAnimationFrame(gameLoop);
}

console.log('✓ Запуск игрового цикла');
gameLoop();
