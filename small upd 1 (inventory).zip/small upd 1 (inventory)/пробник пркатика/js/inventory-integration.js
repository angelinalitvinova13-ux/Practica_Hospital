// Интеграция инвентаря с игровыми событиями
// Этот файл позволяет игроку подбирать предметы и использовать инвентарь

class GameInventoryIntegration {
    constructor() {
        this.setupEventListeners();
    }

    setupEventListeners() {
        // Слушаем событие выбора предмета
        if (window.gameEvents) {
            window.gameEvents.on('inventoryItemSelected', (data) => {
                this.onItemSelected(data);
            });

            window.gameEvents.on('inventoryOpened', () => {
                this.onInventoryOpened();
            });

            window.gameEvents.on('inventoryClosed', () => {
                this.onInventoryClosed();
            });
        }

        // Слушаем клавиши для использования предметов
        document.addEventListener('keydown', (e) => {
            if (e.key >= '1' && e.key <= '9') {
                const slotIndex = parseInt(e.key) - 1;
                this.useItem(slotIndex);
            }
        });
    }

    onItemSelected(data) {
        console.log('Предмет выбран:', data.item);
        // Здесь можно добавить логику использования предмета
    }

    onInventoryOpened() {
        console.log('Инвентарь открыт');
        // Здесь можно добавить эффекты при открытии
    }

    onInventoryClosed() {
        console.log('Инвентарь закрыт');
        // Здесь можно добавить эффекты при закрытии
    }

    useItem(slotIndex) {
        if (!window.inventory || window.inventory.isOpen) {
            return;
        }

        const item = window.inventory.getItem(slotIndex);
        if (!item) {
            return;
        }

        console.log(`Используется предмет: ${item.name}`);

        // Примеры использования разных предметов
        switch (item.name) {
            case 'Зелье маны':
                console.log('Максимальная мана восстановлена!');
                window.inventory.removeItem(slotIndex, 1);
                break;
            case 'Мясо':
                console.log('Здоровье восстановлено!');
                window.inventory.removeItem(slotIndex, 1);
                break;
            case 'Меч':
                console.log('Меч вооружен!');
                break;
            default:
                console.log(`${item.name} используется`);
        }
    }

    // Метод для добавления предметов, найденных в игре
    addFoundItem(icon, name, quantity = 1) {
        if (!window.inventory) {
            return false;
        }
        return window.inventory.addItem(icon, name, quantity);
    }
}

// Инициализация интеграции
let gameInventoryIntegration;

document.addEventListener('DOMContentLoaded', () => {
    // Ждем инициализации инвентаря
    const checkInventory = setInterval(() => {
        if (window.inventory) {
            gameInventoryIntegration = new GameInventoryIntegration();
            clearInterval(checkInventory);
        }
    }, 100);
});

// Экспортируем для использования в других скриптах
window.GameInventoryIntegration = GameInventoryIntegration;
