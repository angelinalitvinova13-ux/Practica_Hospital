// ====================================
// ПРИМЕРЫ ВЗАИМОДЕЙСТВИЯ С ИНВЕНТАРЕМ
// ====================================
// Раскомментируйте нужные части для тестирования!

// Пример 1: Добавить предмет по нажатию клавиши
document.addEventListener('keydown', (e) => {
    // Нажмите G для добавления золота
    if (e.key.toLowerCase() === 'g') {
        if (inventory && !inventory.isOpen) {
            const added = inventory.addItem('💰', 'Золото', 25);
            console.log(added ? '✓ Золото добавлено!' : '✗ Инвентарь переполнен');
        }
    }

    // Нажмите L для добавления зелья
    if (e.key.toLowerCase() === 'l') {
        if (inventory && !inventory.isOpen) {
            const added = inventory.addItem('🧪', 'Зелье маны', 1);
            console.log(added ? '✓ Зелье добавлено!' : '✗ Инвентарь переполнен');
        }
    }

    // Нажмите K для очистки инвентаря (осторожно!)
    if (e.key.toLowerCase() === 'k') {
        if (inventory && confirm('Вы уверены? Это очистит весь инвентарь!')) {
            inventory.items = new Array(inventory.slots).fill(null);
            inventory.render();
            console.log('✓ Инвентарь очищен');
        }
    }
});

// ====================================
// Пример 2: Вывести все предметы в таблицу
// ====================================
function printInventory() {
    if (!inventory) {
        console.error('Инвентарь не инициализирован');
        return;
    }
    const items = inventory.getAllItems();
    console.table(items);
}

// Вызовите в консоли: printInventory()

// ====================================
// Пример 3: Получить количество предмета по названию
// ====================================
function getItemQuantity(name) {
    if (!inventory) return 0;
    
    let total = 0;
    for (let item of inventory.items) {
        if (item && item.name === name) {
            total += item.quantity;
        }
    }
    return total;
}

// Вызовите в консоли: getItemQuantity('Золото')

// ====================================
// Пример 4: Слушать события инвентаря
// ====================================
if (window.gameEvents) {
    // Когда предмет выбран в инвентаре
    window.gameEvents.on('inventoryItemSelected', (data) => {
        console.log(`🎯 Выбран: ${data.item.name}`, data.item);
        
        // Здесь можно добавить эффекты или звуки
        // playSound('select.mp3');
    });

    // Когда инвентарь открыт
    window.gameEvents.on('inventoryOpened', () => {
        console.log('🔓 Инвентарь открыт');
        
        // Пауза игры
        // pauseGame();
    });

    // Когда инвентарь закрыт
    window.gameEvents.on('inventoryClosed', () => {
        console.log('🔒 Инвентарь закрыт');
        
        // Возобновление игры
        // resumeGame();
    });
}

// ====================================
// Пример 5: Симуляция сбора предметов
// ====================================
function simulateItemDrop() {
    if (!inventory) return;

    const randomItems = [
        { icon: '💎', name: 'Драгоценный камень', qty: 1 },
        { icon: '📜', name: 'Древний свиток', qty: 1 },
        { icon: '⚡', name: 'Светящийся кристалл', qty: 2 },
        { icon: '🎯', name: 'Священная стрела', qty: 5 }
    ];

    const randomItem = randomItems[Math.floor(Math.random() * randomItems.length)];
    const added = inventory.addItem(randomItem.icon, randomItem.name, randomItem.qty);

    if (added) {
        console.log(`✓ Найден предмет! ${randomItem.icon} ${randomItem.name}`);
    } else {
        console.log('✗ Не удалось добавить предмет (инвентарь переполнен)');
    }
}

// Вызовите в консоли несколько раз: simulateItemDrop()

// ====================================
// БЫСТРЫЕ КОМАНДЫ ДЛЯ КОНСОЛИ
// ====================================
console.log(`
╔════════════════════════════════════════╗
║    ИНВЕНТАРЬ - КОМАНДЫ ДЛЯ КОНСОЛИ    ║
╠════════════════════════════════════════╣
║                                        ║
║ printInventory()          - список     ║
║ getItemQuantity('Золото') - кол-во    ║
║ simulateItemDrop()        - новый      ║
║ inventory.toggle()        - открыть    ║
║ inventory.open()          - открыть    ║
║ inventory.close()         - закрыть    ║
║                                        ║
║ Клавиши в игре:                        ║
║ I или E - открыть/закрыть инвентарь   ║
║ G - добавить золото                   ║
║ L - добавить зелье                    ║
║ K - очистить инвентарь                ║
║ 1-9 - использовать предмет            ║
║                                        ║
╚════════════════════════════════════════╝
`);

// Экспортируем функции в глобальную область
window.printInventory = printInventory;
window.getItemQuantity = getItemQuantity;
window.simulateItemDrop = simulateItemDrop;
