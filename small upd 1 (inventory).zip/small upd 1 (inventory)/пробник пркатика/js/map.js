class Map {
    constructor(imagePath, width, height) {
        this.image = new Image();
        this.image.src = imagePath;
        this.width = width;
        this.height = height;
        this.loaded = false;

        console.log(`📍 Загрузка карты: ${imagePath}`);

        this.image.onload = () => {
            console.log(`✅ Карта загружена: ${imagePath}`);
            this.loaded = true;
        };

        this.image.onerror = () => {
            console.error(`❌ Ошибка загрузки карты: ${imagePath}`);
            console.error(`Попытка загрузить из: ${this.image.src}`);
        };
    }

    draw(ctx, camera) {
        if (!this.loaded) {
            // Если карта не загружена, рисуем серый фон
            ctx.fillStyle = '#333';
            ctx.fillRect(0, 0, this.width, this.height);
            
            // Выводим сообщение загрузки
            ctx.fillStyle = '#fff';
            ctx.font = 'bold 20px Arial';
            ctx.textAlign = 'center';
            ctx.fillText('⏳ Загрузка карты...', this.width / 2, this.height / 2 - 30);
            
            ctx.font = '14px Arial';
            ctx.fillStyle = '#aaa';
            ctx.fillText('Откройте консоль (F12) для деталей', this.width / 2, this.height / 2 + 20);
            return;
        }

        // Рисуем карту
        ctx.drawImage(
            this.image,
            0,
            0,
            this.width,
            this.height
        );
    }
}
