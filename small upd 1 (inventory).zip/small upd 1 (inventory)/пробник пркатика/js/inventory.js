// Класс для управления инвентарем
class Inventory {
    constructor(gridCols = 6, gridRows = 4) {
        this.gridCols = gridCols;
        this.gridRows = gridRows;
        this.slots = gridCols * gridRows;
        this.items = new Array(this.slots).fill(null);
        this.isOpen = false;

        // Предустановленные предметы
        this.predefinedItems = [
            { icon: '🗡️', name: 'Меч', quantity: 1 },
            { icon: '🛡️', name: 'Щит', quantity: 1 },
            { icon: '🧪', name: 'Зелье маны', quantity: 3 },
            { icon: '💰', name: 'Золото', quantity: 50 },
            { icon: '🍖', name: 'Мясо', quantity: 12 },
            { icon: '⚔️', name: 'Боевой топор', quantity: 1 },
            { icon: '🏹', name: 'Лук', quantity: 1 },
            { icon: '🔱', name: 'Копье', quantity: 2 }
        ];

        this.init();
    }

    init() {
        this.createHTML();
        this.addPredefinedItems();
        this.render();
        this.setupEventListeners();
    }

    createHTML() {
        // Создаем кнопку открытия инвентаря
        const inventoryBtn = document.createElement('button');
        inventoryBtn.className = 'inventory-open-btn';
        inventoryBtn.id = 'inventoryOpenBtn';
        inventoryBtn.innerHTML = '🎒';
        inventoryBtn.title = 'Открыть инвентарь';
        document.body.appendChild(inventoryBtn);

        // Создаем HTML структуру динамически
        const overlay = document.createElement('div');
        overlay.className = 'inventory-overlay';
        overlay.id = 'inventoryOverlay';
        document.body.appendChild(overlay);

        const panel = document.createElement('div');
        panel.className = 'inventory-panel';
        panel.id = 'inventoryPanel';
        panel.innerHTML = `
            <div class="inventory-header">
                <h2>🎒 Инвентарь</h2>
                <div class="inventory-stats">
                    <div class="stat">Слотов: <span id="totalSlots">24</span></div>
                    <div class="stat">Заполнено: <span id="filledSlots">0</span></div>
                </div>
                <button class="close-btn" id="closeBtn">✕</button>
            </div>
            <div class="inventory-grid" id="inventoryGrid"></div>
        `;
        document.body.appendChild(panel);

        const hint = document.createElement('div');
        hint.className = 'keyboard-hint';
        hint.id = 'keyboardHint';
        hint.innerHTML = 'Нажмите <strong>✕</strong> или <strong>I/E</strong> для закрытия инвентаря';
        document.body.appendChild(hint);
    }

    addPredefinedItems() {
        let slotIndex = 0;
        for (let item of this.predefinedItems) {
            if (slotIndex < this.slots) {
                this.items[slotIndex] = { ...item };
                slotIndex++;
            }
        }
    }

    render() {
        const grid = document.getElementById('inventoryGrid');
        grid.innerHTML = '';

        for (let i = 0; i < this.slots; i++) {
            const slot = document.createElement('div');
            slot.className = 'inventory-slot';
            slot.dataset.slotIndex = i;

            if (this.items[i]) {
                const item = this.items[i];
                slot.innerHTML = `
                    <div class="tooltip">${item.name}</div>
                    <div class="item-icon">${item.icon}</div>
                    ${item.quantity > 1 ? `<div class="item-badge">${item.quantity}</div>` : ''}
                `;
                slot.style.cursor = 'pointer';
            } else {
                slot.classList.add('empty');
                slot.innerHTML = '<div class="tooltip">Пусто</div>';
            }

            slot.addEventListener('click', () => this.handleSlotClick(i));
            grid.appendChild(slot);
        }

        this.updateStats();
    }

    handleSlotClick(index) {
        if (this.items[index]) {
            const item = this.items[index];
            console.log(`Выбран предмет: ${item.name}`);
            
            // Триггер события для интеграции с игроком
            if (window.gameEvents) {
                window.gameEvents.emit('inventoryItemSelected', {
                    index: index,
                    item: item
                });
            }
        }
    }

    updateStats() {
        const filledSlots = this.items.filter(item => item !== null).length;
        document.getElementById('totalSlots').textContent = this.slots;
        document.getElementById('filledSlots').textContent = filledSlots;
    }

    setupEventListeners() {
        document.getElementById('closeBtn').addEventListener('click', () => this.close());
        document.getElementById('inventoryOverlay').addEventListener('click', () => this.close());
        document.getElementById('inventoryOpenBtn').addEventListener('click', () => this.toggle());

        // Горячие клавиши - только когда на canvas (не в input полях)
        document.addEventListener('keydown', (e) => {
            // Пропускаем, если пользователь печатает в input
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
                return;
            }

            if (e.key.toLowerCase() === 'i' || e.key.toLowerCase() === 'e') {
                e.preventDefault();
                this.toggle();
            }
        });
    }

    open() {
        if (this.isOpen) return;
        this.isOpen = true;
        document.getElementById('inventoryPanel').classList.add('active');
        document.getElementById('inventoryOverlay').classList.add('active');
        document.getElementById('inventoryOpenBtn').style.display = 'none';
        document.getElementById('keyboardHint').classList.add('show');
        document.body.style.overflow = 'hidden';

        // Отключаем управление игроком при открытии инвентаря
        if (window.gameEvents) {
            window.gameEvents.emit('inventoryOpened');
        }
    }

    close() {
        if (!this.isOpen) return;
        this.isOpen = false;
        document.getElementById('inventoryPanel').classList.remove('active');
        document.getElementById('inventoryOverlay').classList.remove('active');
        document.getElementById('inventoryOpenBtn').style.display = 'flex';
        document.getElementById('keyboardHint').classList.remove('show');
        document.body.style.overflow = 'auto';

        // Включаем управление игроком при закрытии инвентаря
        if (window.gameEvents) {
            window.gameEvents.emit('inventoryClosed');
        }
    }

    toggle() {
        if (this.isOpen) {
            this.close();
        } else {
            this.open();
        }
    }

    // Методы для добавления и удаления предметов
    addItem(icon, name, quantity = 1) {
        // Ищем существующий предмет с тем же названием
        const existingIndex = this.items.findIndex(item => item && item.name === name);
        if (existingIndex !== -1) {
            this.items[existingIndex].quantity += quantity;
            this.render();
            return true;
        }

        // Ищем пустой слот
        const emptySlot = this.items.findIndex(item => item === null);
        if (emptySlot !== -1) {
            this.items[emptySlot] = { icon, name, quantity };
            this.render();
            return true;
        }
        return false;
    }

    removeItem(index, quantity = 1) {
        if (this.items[index]) {
            this.items[index].quantity -= quantity;
            if (this.items[index].quantity <= 0) {
                this.items[index] = null;
            }
            this.render();
            return true;
        }
        return false;
    }

    // Получить предмет из инвентаря
    getItem(index) {
        return this.items[index];
    }

    // Получить все предметы
    getAllItems() {
        return this.items.filter(item => item !== null);
    }
}

// Система событий для коммуникации между компонентами
class EventEmitter {
    constructor() {
        this.events = {};
    }

    on(event, callback) {
        if (!this.events[event]) {
            this.events[event] = [];
        }
        this.events[event].push(callback);
    }

    off(event, callback) {
        if (this.events[event]) {
            this.events[event] = this.events[event].filter(cb => cb !== callback);
        }
    }

    emit(event, data) {
        if (this.events[event]) {
            this.events[event].forEach(callback => callback(data));
        }
    }
}

// Глобальная система событий
window.gameEvents = new EventEmitter();

// Инициализация инвентаря после загрузки страницы
let inventory;

function initializeInventory() {
    if (inventory) return; // Уже инициализирован
    
    // Добавляем CSS в head, если его еще нет
    if (!document.querySelector('link[href="js/inventory.css"]')) {
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = 'js/inventory.css';
        document.head.appendChild(link);
    }

    // Создаем инвентарь
    inventory = new Inventory(6, 4);
    console.log('✅ Инвентарь инициализирован');
}

// Пробуем инициализировать сразу, и если DOM еще не готов, ждем события
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeInventory);
} else {
    // DOM уже готов
    initializeInventory();
}

// Экспортируем для использования в других скриптах
window.Inventory = Inventory;
window.inventory = inventory;
window.initializeInventory = initializeInventory;

// Вспомогательная команда для консоли
window.checkInventoryStatus = function() {
    console.log('📦 Статус инвентаря:');
    console.log('✓ Инвентарь создан:', !!window.inventory);
    console.log('✓ Инвентарь открыт:', window.inventory?.isOpen);
    console.log('✓ Слотов:', window.inventory?.slots);
    console.log('✓ Предметов:', window.inventory?.getAllItems().length);
    console.log('\nДебаг команды:');
    console.log('- inventory.open() // Открыть');
    console.log('- inventory.close() // Закрыть');
    console.log('- inventory.toggle() // Переключить');
};

console.log('💡 Введите в консоль: checkInventoryStatus()');

